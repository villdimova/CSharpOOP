﻿
namespace CollectionHierarchy
{
    public interface IAddRemoveCollection :IAddCollection
    {
        public string Remove();
    }
}
