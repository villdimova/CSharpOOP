﻿namespace CollectionHierarchy
{
    public interface IMyList : IAddRemoveCollection
    {
        public int Used { get;}

    }
}
