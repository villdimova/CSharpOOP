﻿namespace CollectionHierarchy
{
    using System.Collections.Generic;

    public interface IAddCollection
    {
      
        public int Add(string item);
    }
}
