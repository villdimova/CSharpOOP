﻿namespace MilitaryElite
{
    public interface IEngine
    {
        public void Run(); 
        
    }
}
