﻿namespace MilitaryElite
{
   public interface ICommandInterpreter
    {
        public string Read(string[] args);
    }
}
